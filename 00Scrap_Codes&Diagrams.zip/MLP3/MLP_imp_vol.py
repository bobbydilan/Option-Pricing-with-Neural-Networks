"""
MLP3: Implied Volatility Prediction Neural Network
==================================================

This model predicts implied volatility (IV) for options using:
- Standard Black-Scholes variables
- Engineered features (log-forward moneyness, sqrt(T))
- Market microstructure features (bid-ask spread, volume, open interest)
- Economic uncertainty indices
- Sample weighting based on Delta × sqrt(T) buckets
- MAE loss on IV with conversion to price for evaluation

Author: Federico Galli
Date: 2025
"""

import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import norm
import warnings
warnings.filterwarnings('ignore')
from datetime import datetime
from torch.optim.lr_scheduler import ReduceLROnPlateau
import matplotlib.cm as cm
import matplotlib.colors as colors

# ==============================================
# CONFIGURATION PARAMETERS
# ==============================================
# Reproducibility
SEED = 42

# Model Architecture
LAYER_SIZES = [128, 64, 64]  # Size of each hidden layer
LEAKY_RELU_SLOPE = 0.01
DROPOUT_RATE = 0.1  # Dropout rate for regularization

# Training Parameters
EPOCHS = 30
BATCH_SIZE = 2048
LEARNING_RATE = 3e-4
WEIGHT_DECAY = 1e-5  # L2 regularization weight decay
SAMPLE_SIZE = 15000000

# Early Stopping
EARLY_STOPPING_PATIENCE = 20
EARLY_STOPPING_MIN_DELTA = 1e-6

# Learning Rate Scheduler
SCHEDULER_PATIENCE = 5
SCHEDULER_FACTOR = 0.5
SCHEDULER_MIN_LR = 1e-6

# Model Checkpointing
MODEL_SAVE_PATH = 'best_iv_model.pth'
SAVE_OPTIMIZER_STATE = True

# Data Split Configuration
SPLIT_METHOD = 'random'  # 'time' or 'random'
TRAIN_RATIO = 0.7  # 70% train
VAL_RATIO = 0.15   # 15% validation
TEST_RATIO = 0.15  # 15% test
VAL_TEST_SPLIT = 0.5  # Split between val and test when using time split
TIME_SPLIT_DATE = '2016-10-01'  # Split date for time-based split (YYYY-MM-DD)

# Data Filtering
ZERO_VOLUME_INCLUSION = 0.1  # Percentage of zero volume options to include
FILTER_ITM_OPTIONS = True  # Set to True to filter options by moneyness bounds
MONEYNESS_LOWER_BOUND = 0.7  # Lower moneyness bound (S/K)
MONEYNESS_UPPER_BOUND = 1.3  # Upper moneyness bound (S/K)
FILTER_SHORT_TERM = False  # Set to True to filter options by days to maturity range
MIN_DAYS_TO_MATURITY = 0  # Minimum days to maturity to keep
MAX_DAYS_TO_MATURITY = 700  # Maximum days to maturity to keep

# Sample Weighting Configuration
USE_SAMPLE_WEIGHTING = True  # Enable sample weighting based on Delta × sqrt(T)
N_WEIGHT_BUCKETS = 20  # Number of buckets for sample weighting

# Device
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Set matplotlib backend for headless environments
plt.switch_backend('Agg')

# ==============================================
# FEATURE CONFIGURATION
# ==============================================
# Features for IV prediction model
IV_FEATURES = [
    # Standard Black-Scholes variables
    'strike_price', 'spx_close', 'days_to_maturity', 'risk_free_rate', 'dividend_rate',
    
    # Market microstructure features
    'volume', 'open_interest', 'vol_spread',
    
    # Economic uncertainty indices
    'epu_index', 'equity_uncertainty', 'equity_volatility',
    
    # Engineered features
    'sqrt_time_to_maturity',
    
    # Additional features
    'historical_volatility'  # For comparison
]

# ==============================================
# BLACK-SCHOLES FUNCTIONS
# ==============================================
def black_scholes_vectorized(S, K, T, r, sigma, option_type, q=0):
    """
    Vectorized Black-Scholes option pricing formula
    """
    S = np.asarray(S, dtype=float)
    K = np.asarray(K, dtype=float)
    T = np.asarray(T, dtype=float)
    r = np.asarray(r, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    q = np.asarray(q, dtype=float)
    
    # Handle near-zero time to expiration
    T = np.maximum(T, 1e-10)
    
    # Calculate d1 and d2
    d1 = (np.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    
    # Calculate option prices
    if isinstance(option_type, str):
        option_type = np.full_like(S, option_type, dtype=object)
    
    call_mask = (option_type == 'C') | (option_type == 'call')
    put_mask = ~call_mask
    
    prices = np.zeros_like(S)
    
    # Call options
    if np.any(call_mask):
        prices[call_mask] = (S[call_mask] * np.exp(-q[call_mask] * T[call_mask]) * norm.cdf(d1[call_mask]) - 
                            K[call_mask] * np.exp(-r[call_mask] * T[call_mask]) * norm.cdf(d2[call_mask]))
    
    # Put options
    if np.any(put_mask):
        prices[put_mask] = (K[put_mask] * np.exp(-r[put_mask] * T[put_mask]) * norm.cdf(-d2[put_mask]) - 
                           S[put_mask] * np.exp(-q[put_mask] * T[put_mask]) * norm.cdf(-d1[put_mask]))
    
    return prices

def calculate_delta(S, K, T, r, sigma, option_type, q=0):
    """Calculate option delta"""
    T = np.maximum(T, 1e-10)
    d1 = (np.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    
    if isinstance(option_type, str):
        option_type = np.full_like(S, option_type, dtype=object)
    
    call_mask = (option_type == 'C') | (option_type == 'call')
    put_mask = ~call_mask
    
    delta = np.zeros_like(S)
    
    # Call delta
    if np.any(call_mask):
        delta[call_mask] = np.exp(-q[call_mask] * T[call_mask]) * norm.cdf(d1[call_mask])
    
    # Put delta
    if np.any(put_mask):
        delta[put_mask] = -np.exp(-q[put_mask] * T[put_mask]) * norm.cdf(-d1[put_mask])
    
    return delta

# ==============================================
# FEATURE ENGINEERING
# ==============================================
def engineer_features(df):
    """Create engineered features for IV prediction"""
    print("Engineering features for IV prediction...")
    
    # Calculate square root of time to maturity
    T = df['days_to_maturity'] / 365.0
    df['sqrt_time_to_maturity'] = np.sqrt(T)
    
    print(f"   Added engineered features: sqrt_time_to_maturity")
    
    return df

def create_sample_weights(df):
    """Create sample weights based on Delta × sqrt(T) buckets"""
    if not USE_SAMPLE_WEIGHTING:
        return np.ones(len(df))
    
    print("Creating sample weights based on Delta × sqrt(T) buckets...")
    
    # Calculate Delta for weighting
    S = df['spx_close'].values
    K = df['strike_price'].values
    T = df['days_to_maturity'].values / 365.0
    r = df['risk_free_rate'].values / 100.0
    sigma = df['implied_volatility'].values  # Use implied volatility for delta calculation
    option_type = df['cp_flag'].values
    q = df['dividend_rate'].values / 100.0
    
    delta = calculate_delta(S, K, T, r, sigma, option_type, q)
    sqrt_T = np.sqrt(T)
    
    # Create weighting variable: |Delta| × sqrt(T)
    weight_variable = np.abs(delta) * sqrt_T
    
    # Create buckets
    buckets = pd.cut(weight_variable, bins=N_WEIGHT_BUCKETS, labels=False, duplicates='drop')
    
    # Calculate bucket frequencies
    bucket_counts = pd.Series(buckets).value_counts()
    
    # Calculate inverse frequency weights
    weights = np.zeros(len(df))
    for bucket_id in bucket_counts.index:
        mask = buckets == bucket_id
        weights[mask] = 1.0 / bucket_counts[bucket_id]
    
    # Normalize weights to sum to number of samples
    weights = weights * len(weights) / weights.sum()
    
    print(f"   Created {N_WEIGHT_BUCKETS} weight buckets")
    print(f"   Weight range: {weights.min():.4f} - {weights.max():.4f}")
    print(f"   Mean weight: {weights.mean():.4f}")
    
    return weights

# ==============================================
# PYTORCH DATASET CLASS
# ==============================================
class IVPredictionDataset(Dataset):
    def __init__(self, X, y, weights=None):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
        self.weights = torch.FloatTensor(weights) if weights is not None else None
    
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        if self.weights is not None:
            return self.X[idx], self.y[idx], self.weights[idx]
        else:
            return self.X[idx], self.y[idx]

# ==============================================
# PYTORCH MODEL DEFINITION
# ==============================================
class IVPredictionMLP(nn.Module):
    def __init__(self, input_dim: int, layer_sizes=None):
        super().__init__()
        if layer_sizes is None:
            layer_sizes = LAYER_SIZES
            
        layers = []
        prev = input_dim
        
        # Build hidden layers with leaky ReLU activation and dropout
        for i, size in enumerate(layer_sizes):
            layers.append(nn.Linear(prev, size))
            layers.append(nn.LeakyReLU(negative_slope=LEAKY_RELU_SLOPE))
            if DROPOUT_RATE > 0:
                layers.append(nn.Dropout(DROPOUT_RATE))
            prev = size
            
        # Output layer (single output for IV)
        layers.append(nn.Linear(prev, 1))
        
        self.net = nn.Sequential(*layers)
        
        # Apply Glorot (Xavier) initialization
        self._initialize_weights()
    
    def _initialize_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
    
    def forward(self, x):
        return self.net(x)

# ==============================================
# UTILITY FUNCTIONS
# ==============================================
def set_seed(seed):
    """Set random seeds for reproducibility"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def load_dataset(csv_path, sample_size=None, features=None):
    """Load and preprocess the dataset for IV prediction"""
    print(f"Loading dataset from {csv_path}...")
    
    if features is None:
        features = IV_FEATURES
    
    # Load data
    df = pd.read_csv(csv_path)
    print(f"Initial dataset size: {len(df)}")
    
    # Check for basic required columns (before feature engineering)
    basic_required = ['implied_volatility', 'cp_flag', 'mid_price', 'best_bid', 'best_offer', 'days_to_maturity']
    missing_basic = [col for col in basic_required if col not in df.columns]
    
    if missing_basic:
        print(f"Error: Missing required columns: {missing_basic}")
        print("Please run the Black-Scholes analysis first to generate implied volatility columns.")
        return None, None, None
    
    # Apply filtering
    df = apply_data_filters(df)
    
    # Engineer features (this creates sqrt_time_to_maturity)
    df = engineer_features(df)
    
    # Now check for all required feature columns
    missing_features = [col for col in features if col not in df.columns]
    if missing_features:
        print(f"Error: Missing feature columns after engineering: {missing_features}")
        return None, None, None
    
    # Remove rows with missing implied volatility
    initial_size = len(df)
    df = df.dropna(subset=['implied_volatility'])
    removed_na = initial_size - len(df)
    print(f"Removed {removed_na} rows with missing implied volatility")
    
    # Sample data if needed
    if sample_size and len(df) > sample_size:
        df = df.sample(n=sample_size, random_state=SEED)
        print(f"Sampled {sample_size} rows from dataset")
    
    # Prepare features and target
    X = df[features].values
    y = df['implied_volatility'].values  # Target is implied volatility
    
    # Create sample weights
    weights = create_sample_weights(df)
    
    # Store original data for evaluation
    df_original = df.copy()
    
    print(f"Final dataset size: {len(df)}")
    print(f"Feature columns: {features}")
    print(f"Number of features: {len(features)}")
    print(f"IV statistics: mean={y.mean():.4f}, std={y.std():.4f}, min={y.min():.4f}, max={y.max():.4f}")
    
    return X, y, df_original, weights

def apply_data_filters(df):
    """Apply various data filters"""
    initial_size = len(df)
    
    # Filter by moneyness
    if FILTER_ITM_OPTIONS:
        moneyness = df['spx_close'] / df['strike_price']
        before_filter = len(df)
        df = df[(moneyness >= MONEYNESS_LOWER_BOUND) & (moneyness <= MONEYNESS_UPPER_BOUND)]
        filtered_out = before_filter - len(df)
        print(f"Filtered out {filtered_out} options outside moneyness bounds ({MONEYNESS_LOWER_BOUND} to {MONEYNESS_UPPER_BOUND})")
    
    # Handle zero volume options
    if ZERO_VOLUME_INCLUSION < 1.0:
        zero_volume_mask = df['volume'] == 0
        zero_volume_count = zero_volume_mask.sum()
        
        if zero_volume_count > 0:
            # Keep a percentage of zero volume options
            keep_count = int(zero_volume_count * ZERO_VOLUME_INCLUSION)
            zero_volume_indices = df[zero_volume_mask].index
            keep_indices = np.random.choice(zero_volume_indices, keep_count, replace=False)
            
            # Remove zero volume options except the ones we want to keep
            remove_indices = set(zero_volume_indices) - set(keep_indices)
            df = df.drop(remove_indices)
            
            kept_options = len(df)
            print(f"Zero volume handling: kept {kept_options} options ({ZERO_VOLUME_INCLUSION*100:.0f}% of zero volume included)")
    
    # Filter by days to maturity
    if FILTER_SHORT_TERM:
        before_filter = len(df)
        df = df[(df['days_to_maturity'] >= MIN_DAYS_TO_MATURITY) & 
                (df['days_to_maturity'] <= MAX_DAYS_TO_MATURITY)]
        filtered_out = before_filter - len(df)
        print(f"Filtered out {filtered_out} options outside maturity range ({MIN_DAYS_TO_MATURITY}-{MAX_DAYS_TO_MATURITY} days)")
    
    # Remove rows with missing values in key columns
    before_dropna = len(df)
    df = df.dropna(subset=['spx_close', 'strike_price', 'days_to_maturity', 'risk_free_rate', 'mid_price'])
    dropped_na = before_dropna - len(df)
    print(f"Removed {dropped_na} rows with missing values in key columns")
    
    return df

def create_results_directory():
    """Create results directory if it doesn't exist"""
    results_dir = os.path.join(os.path.dirname(__file__), 'results')
    os.makedirs(results_dir, exist_ok=True)
    return results_dir

def train_model(model, train_loader, val_loader, results_dir):
    """Train the IV prediction model with sample weighting"""
    
    # Initialize optimizer with weight decay
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
    
    # Initialize learning rate scheduler
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=SCHEDULER_FACTOR, 
                                patience=SCHEDULER_PATIENCE, min_lr=SCHEDULER_MIN_LR)
    
    criterion = nn.L1Loss(reduction='none')  # MAE loss without reduction for sample weighting
    
    # Training tracking
    train_losses = []
    val_losses = []
    best_val_loss = float('inf')
    patience_counter = 0
    
    model_path = os.path.join(results_dir, MODEL_SAVE_PATH)
    
    print(f"Training on device: {DEVICE}")
    print(f"Architecture: {LAYER_SIZES}")
    print(f"Training samples: {len(train_loader.dataset)}, Validation: {len(val_loader.dataset)}")
    print(f"Loss function: MAE on Implied Volatility")
    
    for epoch in range(EPOCHS):
        # Training phase
        model.train()
        train_loss = 0.0
        
        for batch_data in train_loader:
            if USE_SAMPLE_WEIGHTING and len(batch_data) == 3:
                batch_X, batch_y, batch_weights = batch_data
                batch_X, batch_y, batch_weights = batch_X.to(DEVICE), batch_y.to(DEVICE), batch_weights.to(DEVICE)
            else:
                batch_X, batch_y = batch_data
                batch_X, batch_y = batch_X.to(DEVICE), batch_y.to(DEVICE)
                batch_weights = torch.ones_like(batch_y)
            
            optimizer.zero_grad()
            outputs = model(batch_X).squeeze()
            
            # Calculate weighted MAE loss
            losses = criterion(outputs, batch_y)
            weighted_loss = (losses * batch_weights).mean()
            
            weighted_loss.backward()
            optimizer.step()
            
            train_loss += weighted_loss.item()
        
        train_loss /= len(train_loader)
        train_losses.append(train_loss)
        
        # Validation phase
        model.eval()
        val_loss = 0.0
        
        with torch.no_grad():
            for batch_data in val_loader:
                if len(batch_data) == 3:
                    batch_X, batch_y, batch_weights = batch_data
                    batch_X, batch_y, batch_weights = batch_X.to(DEVICE), batch_y.to(DEVICE), batch_weights.to(DEVICE)
                else:
                    batch_X, batch_y = batch_data
                    batch_X, batch_y = batch_X.to(DEVICE), batch_y.to(DEVICE)
                    batch_weights = torch.ones_like(batch_y)
                
                outputs = model(batch_X).squeeze()
                losses = criterion(outputs, batch_y)
                weighted_loss = (losses * batch_weights).mean()
                val_loss += weighted_loss.item()
        
        val_loss /= len(val_loader)
        val_losses.append(val_loss)
        
        # Learning rate scheduling
        scheduler.step(val_loss)
        
        # Early stopping and checkpointing
        if val_loss < best_val_loss - EARLY_STOPPING_MIN_DELTA:
            best_val_loss = val_loss
            patience_counter = 0
            
            # Save best model
            checkpoint = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict() if SAVE_OPTIMIZER_STATE else None,
                'val_loss': val_loss,
                'train_loss': train_loss,
                'layer_sizes': LAYER_SIZES,
                'learning_rate': LEARNING_RATE,
                'batch_size': BATCH_SIZE
            }
            torch.save(checkpoint, model_path)
            print(f"Model checkpoint saved to {model_path} (IV MAE: {val_loss:.6f})")
        else:
            patience_counter += 1
        
        # Print progress
        if (epoch + 1) % 10 == 0 or epoch == 0:
            current_lr = optimizer.param_groups[0]['lr']
            print(f"Epoch {epoch+1}/{EPOCHS}  |  Train Loss: {train_loss:.6f}  |  Val Loss: {val_loss:.6f}  |  LR: {current_lr:.2e}")
        
        # Early stopping
        if patience_counter >= EARLY_STOPPING_PATIENCE:
            print(f"Early stopping triggered after {epoch+1} epochs")
            break
    
    return train_losses, val_losses, epoch + 1

def evaluate_model(model, test_loader, df_test, results_dir):
    """Evaluate the trained IV prediction model"""
    model.eval()
    
    iv_predictions = []
    iv_actuals = []
    
    print("\n=== Generating IV Predictions ===")
    
    with torch.no_grad():
        for batch_data in test_loader:
            if len(batch_data) == 3:
                batch_X, batch_y, _ = batch_data
            else:
                batch_X, batch_y = batch_data
            
            batch_X = batch_X.to(DEVICE)
            batch_pred = model(batch_X).squeeze()
            
            iv_predictions.extend(batch_pred.cpu().numpy())
            iv_actuals.extend(batch_y.numpy())
    
    iv_predictions = np.array(iv_predictions)
    iv_actuals = np.array(iv_actuals)
    
    # Calculate IV-based metrics
    iv_mae = mean_absolute_error(iv_actuals, iv_predictions)
    iv_mse = mean_squared_error(iv_actuals, iv_predictions)
    iv_r2 = r2_score(iv_actuals, iv_predictions)
    
    # Calculate IV percentage errors
    iv_percentage_errors = 100 * np.abs(iv_predictions - iv_actuals) / iv_actuals
    iv_mean_percentage_error = np.mean(iv_percentage_errors)
    
    print(f"\n--- IV-Based Metrics ---")
    print(f"IV MAE  : {iv_mae:.6f}")
    print(f"IV MSE  : {iv_mse:.6f}")
    print(f"IV R²   : {iv_r2:.6f}")
    print(f"IV MAPE : {iv_mean_percentage_error:.2f}%")
    
    # Convert predicted IV to option prices using Black-Scholes
    print("\n=== Converting IV to Prices for Price-Based Evaluation ===")
    
    S = df_test['spx_close'].values
    K = df_test['strike_price'].values
    T = df_test['days_to_maturity'].values / 365.0
    r = df_test['risk_free_rate'].values / 100.0
    q = df_test['dividend_rate'].values / 100.0
    option_type = df_test['cp_flag'].values
    
    # Convert predicted IV to prices
    predicted_prices = black_scholes_vectorized(S, K, T, r, iv_predictions, option_type, q)
    actual_prices = df_test['mid_price'].values
    
    # Calculate price-based metrics
    price_mae = mean_absolute_error(actual_prices, predicted_prices)
    price_mse = mean_squared_error(actual_prices, predicted_prices)
    price_r2 = r2_score(actual_prices, predicted_prices)
    
    # Calculate price percentage errors
    price_percentage_errors = 100 * np.abs(predicted_prices - actual_prices) / actual_prices
    price_mean_percentage_error = np.mean(price_percentage_errors)
    
    print(f"\n--- Price-Based Metrics (from Predicted IV) ---")
    print(f"Price MAE  : ${price_mae:.4f}")
    print(f"Price MSE  : {price_mse:.4f}")
    print(f"Price R²   : {price_r2:.6f}")
    print(f"Price MAPE : {price_mean_percentage_error:.2f}%")
    
    # Calculate bid-ask spread analysis
    bid_prices = df_test['best_bid'].values
    ask_prices = df_test['best_offer'].values
    
    # Check how many predictions fall within bid-ask spread
    within_spread = (predicted_prices >= bid_prices) & (predicted_prices <= ask_prices)
    pct_within_spread = np.mean(within_spread) * 100
    
    print(f"\n--- Bid-Ask Spread Analysis ---")
    print(f"Predictions within bid-ask spread: {pct_within_spread:.2f}%")
    
    # Export predictions
    predictions_df = df_test.copy()
    predictions_df['predicted_iv'] = iv_predictions
    predictions_df['actual_iv'] = iv_actuals
    predictions_df['predicted_price'] = predicted_prices
    predictions_df['actual_price'] = actual_prices
    predictions_df['iv_error'] = iv_predictions - iv_actuals
    predictions_df['price_error'] = predicted_prices - actual_prices
    predictions_df['iv_percentage_error'] = iv_percentage_errors
    predictions_df['price_percentage_error'] = price_percentage_errors
    predictions_df['within_bid_ask'] = within_spread
    
    csv_path = os.path.join(results_dir, 'iv_predictions.csv')
    predictions_df.to_csv(csv_path, index=False)
    print(f"\nPredictions CSV exported to: {csv_path}")
    print(f"CSV contains {len(predictions_df)} test samples")
    
    return {
        'iv_mae': iv_mae, 'iv_mse': iv_mse, 'iv_r2': iv_r2, 'iv_mape': iv_mean_percentage_error,
        'price_mae': price_mae, 'price_mse': price_mse, 'price_r2': price_r2, 'price_mape': price_mean_percentage_error,
        'pct_within_spread': pct_within_spread,
        'iv_predictions': iv_predictions, 'iv_actuals': iv_actuals,
        'predicted_prices': predicted_prices, 'actual_prices': actual_prices
    }

def plot_iv_analysis(metrics, results_dir):
    """Create comprehensive IV analysis plots"""
    
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    
    # 1. IV Predictions vs Actuals
    axes[0, 0].scatter(metrics['iv_actuals'], metrics['iv_predictions'], alpha=0.5, s=1)
    axes[0, 0].plot([metrics['iv_actuals'].min(), metrics['iv_actuals'].max()], 
                    [metrics['iv_actuals'].min(), metrics['iv_actuals'].max()], 'r--', lw=2)
    axes[0, 0].set_xlabel('Actual IV')
    axes[0, 0].set_ylabel('Predicted IV')
    axes[0, 0].set_title(f'IV Predictions vs Actuals\nR² = {metrics["iv_r2"]:.4f}')
    axes[0, 0].grid(True, alpha=0.3)
    
    # 2. Price Predictions vs Actuals
    axes[0, 1].scatter(metrics['actual_prices'], metrics['predicted_prices'], alpha=0.5, s=1)
    axes[0, 1].plot([metrics['actual_prices'].min(), metrics['actual_prices'].max()], 
                    [metrics['actual_prices'].min(), metrics['actual_prices'].max()], 'r--', lw=2)
    axes[0, 1].set_xlabel('Actual Price ($)')
    axes[0, 1].set_ylabel('Predicted Price ($)')
    axes[0, 1].set_title(f'Price Predictions vs Actuals\nR² = {metrics["price_r2"]:.4f}')
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. IV Error Distribution
    iv_errors = metrics['iv_predictions'] - metrics['iv_actuals']
    axes[0, 2].hist(iv_errors, bins=50, alpha=0.7, color='lightblue', edgecolor='black')
    axes[0, 2].set_xlabel('IV Error')
    axes[0, 2].set_ylabel('Frequency')
    axes[0, 2].set_title(f'IV Error Distribution\nMAE = {metrics["iv_mae"]:.6f}')
    axes[0, 2].grid(True, alpha=0.3)
    
    # 4. Price Error Distribution
    price_errors = metrics['predicted_prices'] - metrics['actual_prices']
    axes[1, 0].hist(price_errors, bins=50, alpha=0.7, color='lightcoral', edgecolor='black')
    axes[1, 0].set_xlabel('Price Error ($)')
    axes[1, 0].set_ylabel('Frequency')
    axes[1, 0].set_title(f'Price Error Distribution\nMAE = ${metrics["price_mae"]:.4f}')
    axes[1, 0].grid(True, alpha=0.3)
    
    # 5. IV vs Price Error Correlation
    axes[1, 1].scatter(np.abs(iv_errors), np.abs(price_errors), alpha=0.5, s=1)
    axes[1, 1].set_xlabel('Absolute IV Error')
    axes[1, 1].set_ylabel('Absolute Price Error ($)')
    axes[1, 1].set_title('IV vs Price Error Correlation')
    axes[1, 1].grid(True, alpha=0.3)
    
    # 6. Performance Summary
    axes[1, 2].axis('off')
    summary_text = f"""
    IV PREDICTION PERFORMANCE
    
    IV Metrics:
    • MAE: {metrics['iv_mae']:.6f}
    • R²: {metrics['iv_r2']:.4f}
    • MAPE: {metrics['iv_mape']:.2f}%
    
    Price Metrics (from IV):
    • MAE: ${metrics['price_mae']:.4f}
    • R²: {metrics['price_r2']:.4f}
    • MAPE: {metrics['price_mape']:.2f}%
    
    Bid-Ask Analysis:
    • Within Spread: {metrics['pct_within_spread']:.2f}%
    """
    axes[1, 2].text(0.1, 0.9, summary_text, transform=axes[1, 2].transAxes, 
                    fontsize=12, verticalalignment='top', fontfamily='monospace')
    
    plt.tight_layout()
    
    # Save plot
    plot_path = os.path.join(results_dir, 'iv_analysis.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"IV analysis plots saved to {plot_path}")

# ==============================================
# MAIN EXECUTION
# ==============================================
if __name__ == "__main__":
    # Set random seed
    set_seed(SEED)
    
    # Create results directory
    results_dir = create_results_directory()
    print(f"Results will be saved to: {results_dir}")
    
    # Load dataset
    csv_path = "/Users/federicogalli/Desktop/THESIS/Code/final_options_dataset.csv"
    result = load_dataset(csv_path, sample_size=SAMPLE_SIZE, features=IV_FEATURES)
    
    if result[0] is None:
        print("Failed to load dataset. Please run Black-Scholes analysis first.")
        exit(1)
    
    X, y, df_original, weights = result
    
    # Data diagnostics
    print(f"\n--- Data Range Diagnostics ---")
    print(f"IV Range: {y.min():.4f} - {y.max():.4f}")
    print(f"IV Mean: {y.mean():.4f}")
    print(f"IV Median: {np.median(y):.4f}")
    print(f"IV 95th percentile: {np.percentile(y, 95):.4f}")
    
    # Split data
    if SPLIT_METHOD == 'random':
        print("Using random split with sample weighting")
        X_train, X_temp, y_train, y_temp, train_idx, temp_idx = train_test_split(
            X, y, range(len(X)), test_size=(1-TRAIN_RATIO), random_state=SEED, stratify=None)
        
        X_val, X_test, y_val, y_test, val_idx, test_idx = train_test_split(
            X_temp, y_temp, temp_idx, test_size=TEST_RATIO/(VAL_RATIO+TEST_RATIO), random_state=SEED)
        
        # Split weights accordingly
        weights_train = weights[train_idx]
        weights_val = weights[val_idx] if USE_SAMPLE_WEIGHTING else None
        weights_test = weights[test_idx] if USE_SAMPLE_WEIGHTING else None
        
        df_train = df_original.iloc[train_idx].reset_index(drop=True)
        df_val = df_original.iloc[val_idx].reset_index(drop=True)  
        df_test = df_original.iloc[test_idx].reset_index(drop=True)
    
    # Apply Z-Score scaling after train/test split
    print("Applying Z-Score scaling (mean=0, std=1) after train/test split...")
    scaler_x, scaler_y = StandardScaler(), StandardScaler()  # Z-Score normalization
    
    # Fit scalers only on training data
    scaler_x.fit(X_train)
    scaler_y.fit(y_train.reshape(-1, 1))
    
    # Transform all sets using training-fitted scalers
    X_train = scaler_x.transform(X_train)
    X_val = scaler_x.transform(X_val)
    X_test = scaler_x.transform(X_test)
    y_train = scaler_y.transform(y_train.reshape(-1, 1)).flatten()
    y_val = scaler_y.transform(y_val.reshape(-1, 1)).flatten()
    y_test = scaler_y.transform(y_test.reshape(-1, 1)).flatten()

    # Create data loaders with sample weighting
    if USE_SAMPLE_WEIGHTING:
        train_dataset = IVPredictionDataset(X_train, y_train, weights_train)
        val_dataset = IVPredictionDataset(X_val, y_val, weights_val)
        test_dataset = IVPredictionDataset(X_test, y_test, weights_test)
    else:
        train_dataset = IVPredictionDataset(X_train, y_train)
        val_dataset = IVPredictionDataset(X_val, y_val)
        test_dataset = IVPredictionDataset(X_test, y_test)
    
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    print(f"Using device: {DEVICE}")
    print(f"Training samples: {len(X_train)}, Validation: {len(X_val)}, Test: {len(X_test)}")
    print(f"Seed: {SEED}")
    
    # Initialize model
    input_dim = X_train.shape[1]
    model = IVPredictionMLP(input_dim, LAYER_SIZES).to(DEVICE)
    
    # Train model
    print(f"\n--- Training MLP3 (IV Prediction) ---")
    train_losses, val_losses, final_epoch = train_model(model, train_loader, val_loader, results_dir)
    
    # Load best model for evaluation
    model_path = os.path.join(results_dir, MODEL_SAVE_PATH)
    checkpoint = torch.load(model_path, map_location=DEVICE)
    model.load_state_dict(checkpoint['model_state_dict'])
    
    # Evaluate model
    print(f"\n--- Evaluating MLP3 Model ---")
    
    # Inverse transform predictions for evaluation
    y_test_original = scaler_y.inverse_transform(y_test.reshape(-1, 1)).flatten()
    
    # Get model predictions on test set
    model.eval()
    test_predictions = []
    with torch.no_grad():
        for batch_data in test_loader:
            if len(batch_data) == 3:
                batch_X, _, _ = batch_data
            else:
                batch_X, _ = batch_data
            batch_X = batch_X.to(DEVICE)
            batch_pred = model(batch_X).squeeze()
            test_predictions.extend(batch_pred.cpu().numpy())
    
    test_predictions = np.array(test_predictions)
    test_predictions_original = scaler_y.inverse_transform(test_predictions.reshape(-1, 1)).flatten()
    
    # Update test predictions in df_test for evaluation
    df_test_eval = df_test.copy()
    df_test_eval['predicted_iv_scaled'] = test_predictions_original
    
    # Calculate metrics and generate visualizations
    metrics = evaluate_model(model, test_loader, df_test_eval, results_dir)
    
    # Generate analysis plots
    print(f"\n--- Generating Visualizations ---")
    plot_iv_analysis(metrics, results_dir)
    
    print(f"\n--- Training Complete ---")
    print(f"Final epoch: {final_epoch}")
    print(f"Best validation loss: {checkpoint['val_loss']:.6f}")
    print(f"Best model saved to: {model_path}")
    print(f"All results saved to: {results_dir}")
    
    print(f"\n--- MLP3 Model Summary ---")
    print(f"Model Type: Implied Volatility Prediction")
    print(f"Target Variable: Implied Volatility (IV)") 
    print(f"Features: {len(IV_FEATURES)} ({', '.join(IV_FEATURES)})")
    print(f"Architecture: {LAYER_SIZES}")
    print(f"Sample Weighting: {'Enabled' if USE_SAMPLE_WEIGHTING else 'Disabled'}")
    print(f"Final IV MAE: {metrics['iv_mae']:.6f}")
    print(f"Final Price MAE: ${metrics['price_mae']:.4f}")
    print(f"Final IV R²: {metrics['iv_r2']:.4f}")
    print(f"Final Price R²: {metrics['price_r2']:.4f}")
    print(f"Predictions within bid-ask spread: {metrics['pct_within_spread']:.2f}%")

print("MLP3: Implied Volatility Prediction Model - Configuration Loaded")
print(f"Target: Implied Volatility (IV)")
print(f"Features: {len(IV_FEATURES)} features including engineered and market microstructure variables")
print(f"Sample Weighting: {'Enabled' if USE_SAMPLE_WEIGHTING else 'Disabled'} (Delta × sqrt(T) buckets)")
print(f"Loss Function: MAE on IV")
print(f"Evaluation: Both IV-based and price-based metrics")