import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import norm
import warnings
warnings.filterwarnings('ignore')
from datetime import datetime
from torch.optim.lr_scheduler import ReduceLROnPlateau
import matplotlib.cm as cm
import matplotlib.colors as colors

# ==============================================
# CONFIGURATION PARAMETERS
# ==============================================
# Reproducibility
SEED = 42

# Model Architecture
LAYER_SIZES = [128, 64, 64]  # Size of each hidden layer
LEAKY_RELU_SLOPE = 0.01
DROPOUT_RATE = 0.0  # Dropout rate for regularization

# Training Parameters
EPOCHS = 50
BATCH_SIZE = 2048 #use larger for more data
LEARNING_RATE = 3e-4
WEIGHT_DECAY = 1e-5  # L2 regularization weight decay
SAMPLE_SIZE = 15000000

# Early Stopping
EARLY_STOPPING_PATIENCE = 20
EARLY_STOPPING_MIN_DELTA = 1e-6

# Learning Rate Scheduler
SCHEDULER_PATIENCE = 5
SCHEDULER_FACTOR = 0.5
SCHEDULER_MIN_LR = 1e-6

# Model Checkpointing
MODEL_SAVE_PATH = 'best_model.pth'
SAVE_OPTIMIZER_STATE = True

# Data Split Configuration
SPLIT_METHOD = 'random'  # 'time' or 'random'
TRAIN_RATIO = 0.7  # 70% train
VAL_RATIO = 0.15   # 15% validation
TEST_RATIO = 0.15  # 15% test
VAL_TEST_SPLIT = 0.5  # Split between val and test when using time split
TIME_SPLIT_DATE = '2016-10-01'  # Split date for time-based split (YYYY-MM-DD)

# Data Filtering
ZERO_VOLUME_INCLUSION = 0.1  # Percentage of zero volume options to include (1.0 = all, 0.0 = none)
FILTER_ITM_OPTIONS = True  # Set to True to filter options by moneyness bounds
MONEYNESS_LOWER_BOUND = 0.8  # Lower moneyness bound (S/K) - exclude options below this
MONEYNESS_UPPER_BOUND = 1  # Upper moneyness bound (S/K) - exclude options above this
FILTER_SHORT_TERM = False  # Set to True to filter options by days to maturity range
MIN_DAYS_TO_MATURITY = 0  # Minimum days to maturity to keep
MAX_DAYS_TO_MATURITY = 700  # Maximum days to maturity to keep

# Device
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
TRAIN_RATIO = 0.7
VAL_TEST_SPLIT = 0.5
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
plt.switch_backend('Agg')

# --------------------------
# Black-Scholes Implementation
# --------------------------
def black_scholes_call(S, K, T, r, sigma):
    """Calculate Black-Scholes call option price"""
    # Handle arrays properly
    T = np.maximum(T, 1e-10)  # Avoid division by zero
    
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    
    call_price = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
    
    # Handle expired options
    expired_mask = T <= 1e-10
    call_price = np.where(expired_mask, np.maximum(S - K, 0), call_price)
    
    return call_price

def calculate_bs_greeks(S, K, T, r, sigma):
    """Calculate Black-Scholes Greeks for call options"""
    # Handle arrays properly
    T = np.maximum(T, 1e-10)  # Avoid division by zero
    
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    
    delta = norm.cdf(d1)
    gamma = norm.pdf(d1) / (S * sigma * np.sqrt(T))
    theta = -(S * norm.pdf(d1) * sigma / (2 * np.sqrt(T)) + r * K * np.exp(-r * T) * norm.cdf(d2)) / 365
    vega = S * norm.pdf(d1) * np.sqrt(T) / 100
    rho = K * T * np.exp(-r * T) * norm.cdf(d2) / 100
    
    # Handle expired options
    expired_mask = T <= 1e-10
    delta = np.where(expired_mask, np.where(S > K, 1.0, 0.0), delta)
    gamma = np.where(expired_mask, 0.0, gamma)
    theta = np.where(expired_mask, 0.0, theta)
    vega = np.where(expired_mask, 0.0, vega)
    rho = np.where(expired_mask, 0.0, rho)
    
    return {'delta': delta, 'gamma': gamma, 'theta': theta, 'vega': vega, 'rho': rho}

# --------------------------
# Model Classes
# --------------------------
class ResidualDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32).view(-1, 1)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

class ResidualMLP(nn.Module):
    def __init__(self, input_dim: int, layer_sizes=None):
        super().__init__()
        if layer_sizes is None:
            layer_sizes = LAYER_SIZES
            
        layers = []
        prev = input_dim
        
        for size in layer_sizes:
            layers.append(nn.Linear(prev, size))
            layers.append(nn.LeakyReLU(negative_slope=0.01))
            prev = size
            
        layers.append(nn.Linear(prev, 1))
        self.net = nn.Sequential(*layers)
        
        # Xavier initialization
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def forward(self, x):
        return self.net(x)

# --------------------------
# Utility Functions
# --------------------------
def set_seed(seed):
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def calculate_metrics(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    epsilon = 1e-8
    mape = np.mean(np.abs((y_true - y_pred) / (y_true + epsilon))) * 100
    return {'mae': mae, 'mse': mse, 'r2': r2, 'mape': mape}

def plot_results(train_losses, val_losses, y_true, y_pred, bs_prices, true_prices, results_dir):
    # Loss curves
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(train_losses, label='Training Loss')
    plt.plot(val_losses, label='Validation Loss')
    plt.title('Training Progress')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True)
    
    plt.subplot(1, 2, 2)
    plt.plot(train_losses, label='Training Loss')
    plt.plot(val_losses, label='Validation Loss')
    plt.title('Training Progress (Log Scale)')
    plt.xlabel('Epoch')
    plt.ylabel('Loss (Log Scale)')
    plt.yscale('log')
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, 'residual_loss_curves.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # Residual analysis
    residuals = y_true - y_pred
    corrected_prices = bs_prices + y_pred
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    # True vs Predicted Residuals
    axes[0, 0].scatter(y_true, y_pred, alpha=0.5, s=1)
    axes[0, 0].plot([y_true.min(), y_true.max()], [y_true.min(), y_true.max()], 'r--', lw=2)
    axes[0, 0].set_xlabel('True Residuals')
    axes[0, 0].set_ylabel('Predicted Residuals')
    axes[0, 0].set_title('True vs Predicted Residuals')
    axes[0, 0].grid(True)
    
    # Black-Scholes vs True Prices
    axes[0, 1].scatter(true_prices, bs_prices, alpha=0.5, s=1)
    axes[0, 1].plot([true_prices.min(), true_prices.max()], [true_prices.min(), true_prices.max()], 'r--', lw=2)
    axes[0, 1].set_xlabel('True Option Prices')
    axes[0, 1].set_ylabel('Black-Scholes Prices')
    axes[0, 1].set_title('Black-Scholes vs True Prices')
    axes[0, 1].grid(True)
    
    # Corrected Prices vs True Prices
    axes[1, 0].scatter(true_prices, corrected_prices, alpha=0.5, s=1)
    axes[1, 0].plot([true_prices.min(), true_prices.max()], [true_prices.min(), true_prices.max()], 'r--', lw=2)
    axes[1, 0].set_xlabel('True Option Prices')
    axes[1, 0].set_ylabel('Corrected Prices (BS + Predicted Residuals)')
    axes[1, 0].set_title('Corrected vs True Prices')
    axes[1, 0].grid(True)
    
    # Error Improvement
    bs_errors = np.abs(true_prices - bs_prices)
    corrected_errors = np.abs(true_prices - corrected_prices)
    
    axes[1, 1].scatter(bs_errors, corrected_errors, alpha=0.5, s=1)
    axes[1, 1].plot([bs_errors.min(), bs_errors.max()], [bs_errors.min(), bs_errors.max()], 'r--', lw=2)
    axes[1, 1].set_xlabel('Black-Scholes Absolute Error')
    axes[1, 1].set_ylabel('Corrected Model Absolute Error')
    axes[1, 1].set_title('Error Improvement Analysis')
    axes[1, 1].grid(True)
    
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, 'residual_analysis.png'), dpi=300, bbox_inches='tight')
    plt.close()

# --------------------------
# Data Loading
# --------------------------
def load_residual_dataset(csv_path: str, sample_size: int = 1000000):
    df = pd.read_csv(csv_path)
    print(f"Initial dataset size: {len(df)}")
    
    # Required columns for Black-Scholes calculation
    required_columns = ['spx_close', 'strike_price', 'days_to_maturity', 'risk_free_rate', 'historical_volatility', 'mid_price']
    df = df.dropna(subset=required_columns)
    
    # Apply basic filtering
    moneyness = df['spx_close'] / df['strike_price']
    df = df[(moneyness >= 0.8) & (moneyness <= 1.2)]  # Filter by moneyness
    df = df[df['days_to_maturity'] > 0]  # Remove expired options
    
    if len(df) > sample_size:
        df = df.sample(sample_size, random_state=42)
    
    print(f"Final dataset size: {len(df)}")
    
    # Calculate Black-Scholes prices
    S = df['spx_close'].values
    K = df['strike_price'].values
    T = df['days_to_maturity'].values / 365.0
    r = df['risk_free_rate'].values / 100.0  # Convert percentage to decimal
    sigma = df['historical_volatility'].values / 100.0  # Convert percentage to decimal
    true_prices = df['mid_price'].values
    
    print("Calculating Black-Scholes prices...")
    bs_prices = black_scholes_call(S, K, T, r, sigma)
    residuals = true_prices - bs_prices
    
    # Calculate Greeks as additional features (vectorized)
    print("Calculating Black-Scholes Greeks...")
    greeks = calculate_bs_greeks(S, K, T, r, sigma)
    
    # Features: Black-Scholes inputs + Greeks + Black-Scholes price
    features = np.column_stack([
        S, K, T, r, sigma, bs_prices,
        greeks['delta'], greeks['gamma'], greeks['theta'], greeks['vega'], greeks['rho']
    ])
    
    print(f"Feature matrix shape: {features.shape}")
    print(f"Residuals statistics: mean={residuals.mean():.4f}, std={residuals.std():.4f}")
    
    # Scale features and target
    scaler_x = StandardScaler()
    scaler_y = StandardScaler()
    
    X_scaled = scaler_x.fit_transform(features)
    y_scaled = scaler_y.fit_transform(residuals.reshape(-1, 1)).flatten()
    
    return X_scaled, y_scaled, scaler_x, scaler_y, df, bs_prices, true_prices, residuals

# --------------------------
# Training Function
# --------------------------
def train_residual_model():
    set_seed(SEED)
    
    # Create results folder inside the current directory
    results_dir = 'results'
    os.makedirs(results_dir, exist_ok=True)
    print(f"Results will be saved to: {results_dir}")
    
    # Load data
    csv_path = "/Users/federicogalli/Desktop/THESIS/Code/final_options_dataset.csv"
    
    X, y, scaler_x, scaler_y, df_original, bs_prices, true_prices, residuals = load_residual_dataset(csv_path, SAMPLE_SIZE)
    
    # Split data
    test_size = 1 - TRAIN_RATIO
    indices = np.arange(len(X))
    X_train, X_temp, y_train, y_temp, idx_train, idx_temp = train_test_split(
        X, y, indices, test_size=test_size, random_state=SEED)
    X_val, X_test, y_val, y_test, idx_val, idx_test = train_test_split(
        X_temp, y_temp, idx_temp, test_size=VAL_TEST_SPLIT, random_state=SEED)
    
    # Create data loaders
    train_loader = DataLoader(ResidualDataset(X_train, y_train), batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(ResidualDataset(X_val, y_val), batch_size=BATCH_SIZE)
    test_loader = DataLoader(ResidualDataset(X_test, y_test), batch_size=BATCH_SIZE)
    
    print(f"Training samples: {len(X_train)}, Validation: {len(X_val)}, Test: {len(X_test)}")
    
    # Initialize model
    model = ResidualMLP(input_dim=X.shape[1]).to(DEVICE)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.MSELoss()
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5)
    
    # Training loop
    train_losses = []
    val_losses = []
    best_val_loss = float('inf')
    patience = 10
    patience_counter = 0
    
    print("\n--- Starting Training ---")
    
    for epoch in range(EPOCHS):
        # Training phase
        model.train()
        train_loss = 0.0
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(DEVICE), batch_y.to(DEVICE)
            
            optimizer.zero_grad()
            outputs = model(batch_x)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # Validation phase
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch_x, batch_y in val_loader:
                batch_x, batch_y = batch_x.to(DEVICE), batch_y.to(DEVICE)
                outputs = model(batch_x)
                loss = criterion(outputs, batch_y)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        
        train_losses.append(train_loss)
        val_losses.append(val_loss)
        
        scheduler.step(val_loss)
        
        # Save best model
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), os.path.join(results_dir, 'best_residual_model.pth'))
            patience_counter = 0
        else:
            patience_counter += 1
        
        if (epoch + 1) % 10 == 0:
            print(f"Epoch [{epoch+1}/{EPOCHS}] - Train Loss: {train_loss:.6f}, Val Loss: {val_loss:.6f}")
        
        # Early stopping
        if patience_counter >= patience:
            print(f"Early stopping at epoch {epoch+1}")
            break
    
    # Load best model and evaluate
    model.load_state_dict(torch.load(os.path.join(results_dir, 'best_residual_model.pth')))
    model.eval()
    
    preds = []
    trues = []
    
    with torch.no_grad():
        for xb, yb in test_loader:
            xb = xb.to(DEVICE)
            out = model(xb).cpu().numpy().flatten()
            preds.extend(out)
            trues.extend(yb.numpy().flatten())
    
    # Inverse transform
    preds = scaler_y.inverse_transform(np.array(preds).reshape(-1, 1)).flatten()
    trues = scaler_y.inverse_transform(np.array(trues).reshape(-1, 1)).flatten()
    
    # Calculate metrics
    metrics = calculate_metrics(trues, preds)
    
    # Get test data for analysis
    test_bs_prices = bs_prices[idx_test]
    test_true_prices = true_prices[idx_test]
    
    # Calculate improvement
    bs_mae = mean_absolute_error(test_true_prices, test_bs_prices)
    corrected_prices = test_bs_prices + preds
    corrected_mae = mean_absolute_error(test_true_prices, corrected_prices)
    improvement = (bs_mae - corrected_mae) / bs_mae * 100
    
    print("\n--- Test Metrics (Residual Prediction) ---")
    print(f"Residual MSE  : {metrics['mse']:.6f}")
    print(f"Residual MAE  : {metrics['mae']:.6f}")
    print(f"Residual R²   : {metrics['r2']:.6f}")
    print(f"Residual MAPE : {metrics['mape']:.2f}%")
    
    print("\n--- Price Prediction Improvement ---")
    print(f"Black-Scholes MAE     : {bs_mae:.6f}")
    print(f"Corrected Model MAE   : {corrected_mae:.6f}")
    print(f"Improvement           : {improvement:.2f}%")
    
    # Generate plots
    plot_results(train_losses, val_losses, trues, preds, test_bs_prices, test_true_prices, results_dir)
    
    # Save summary
    with open(os.path.join(results_dir, 'residual_summary.txt'), 'w') as f:
        f.write("Residual MLP Training Summary\n")
        f.write("============================\n\n")
        f.write(f"Architecture: {LAYER_SIZES}\n")
        f.write(f"Epochs: {len(train_losses)}\n")
        f.write(f"Best Validation Loss: {min(val_losses):.6f}\n\n")
        f.write("Residual Prediction Metrics:\n")
        f.write(f"- MSE: {metrics['mse']:.6f}\n")
        f.write(f"- MAE: {metrics['mae']:.6f}\n")
        f.write(f"- R²: {metrics['r2']:.6f}\n")
        f.write(f"- MAPE: {metrics['mape']:.2f}%\n\n")
        f.write("Price Prediction Improvement:\n")
        f.write(f"- Black-Scholes MAE: {bs_mae:.6f}\n")
        f.write(f"- Corrected Model MAE: {corrected_mae:.6f}\n")
        f.write(f"- Improvement: {improvement:.2f}%\n")
    
    print(f"\nTraining complete! Results saved to: {results_dir}")

if __name__ == "__main__":
    train_residual_model()
